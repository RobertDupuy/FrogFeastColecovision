FROG FEAST — COLECOVISION SOUND REPAIR
October 2026

Load FrogFeast-Sound.rom in a ColecoVision emulator or a compatible cartridge.
This is a standard 32 KiB ROM for an unexpanded ColecoVision.

WHAT CHANGED

The 2007 port now has a replacement SN76489 sound engine, a 44-second looping
arrangement of the supplied Uzebox title music, a nine-second ending tune,
and jump, tongue, fly-catch, and splash effects for both frogs. Music plays on
the title and game-over screens only. Gameplay has sound effects only, with
an independent effect voice for each frog and silence between effects.

The Uzebox audio has been arranged for the ColecoVision's three square-wave
voices and noise channel. Its sampled waveforms cannot be reproduced exactly
by that chip. Notes, rhythm, and effect pitch/envelope contours are adapted
from the supplied files; this is not a recording of the Sega CD soundtrack.

The existing game logic, graphics, controls, scoring, and opponent AI are
preserved. The ROM's former sound entry points are redirected or disabled.
No expansion module, additional RAM, or bank switching is required.

CONTROLS

On the title screen, use up/down to select one or two players, then fire.
Use left/right to face and hop. Press fire to jump and again in the air to
extend the frog's tongue. At the end of a round, release and press fire again.

CREDITS

Original Frog Feast: Charles Doty / RasterSoft.
Original ColecoVision port: Mark2008 (Mark2006).
Audio source: the supplied Uzebox Frog Feast port by Lee Weber (D3thAdd3r),
identified as 2015 in its gameinfo.properties. Its source archive carries
the GNU GPL version 3; a copy is retained with the source audio assets.

BUILD AND VALIDATION

The source folder contains the new Z80 sound engine, the supplied music and
effect definitions, their converter, the exact original ROM used as input,
and a guarded patch builder. This is the sound repair source, not recovered
ColecoVision C source. Build requirements: Python 3 and the Pasmo assembler.

    cd source
    python3 build.py

If Pasmo is outside PATH, pass its absolute executable path to build.py.
The builder verifies the original ROM's SHA-256 before applying any changes.

MAME 0.264 NTSC testing covered title selection, one-player gameplay, a full
two-player round and the ending screen. The game timer advanced
once per emulated frame during the round. Independent Z80 tests covered
music looping, silence during gameplay when no effects are active,
simultaneous effects for both players, effect completion, ending-track
silence, RAM/stack boundaries, and PSG write spacing.

Physical ColecoVision hardware has not been tested. PAL timing has not been
validated; the music is currently timed for 60 Hz operation.

The separate MP4 preview is captured from this ROM in MAME. Its audio is
DC-filtered and raised 6 dB for the preview; no separate soundtrack is added.

See validation.txt for measurements and ROM hashes.
