; Frog Feast ColecoVision sound repair.
; Z80 / SN76489, standard ColecoVision RAM and ROM only.
; Music and effect contours adapted from Lee Weber's Uzebox assets.
; All sound hardware writes happen here in the existing VBlank handler.

 org 0d500h
BASE        equ 071a1h
MODE        equ BASE
REQUEST     equ BASE+1
MPTR        equ BASE+2
MTIMER      equ BASE+4
NOTES       equ BASE+6
AGES        equ BASE+10
FX1         equ BASE+16
FX2         equ BASE+24
PREV1       equ BASE+32
PREV2       equ BASE+34
NOISELAST   equ BASE+36
TICKS       equ BASE+38

; Startup trampoline replaces LD HL,$0033 after the original RAM clear.
audio_init:
 ld hl,BASE
 ld de,BASE+1
 ld bc,63
 xor a
 ld (hl),a
 ldir
 dec a
 ld (REQUEST),a
 ld (NOISELAST),a
 call silence
 ld hl,0033h
 ret

title_request:
 push af
 ld a,1
 jr request_mode
game_request:
 push af
 ld a,2
 jr request_mode
end_request:
 push af
 ld a,3
 jr request_mode
mute_request:
 push af
 xor a
request_mode:
 ld (REQUEST),a
 pop af
 ret

; Runs with both Z80 register banks already saved by the original NMI.
audio_tick:
 ld hl,(TICKS)
 inc hl
 ld (TICKS),hl
 ld a,(REQUEST)
 cp 255
 call nz,change_mode
 ld a,(MODE)
 or a
 ret z
 call music_step
 ld a,(MODE)
 cp 2
 call z,poll_effects
 ld ix,FX1
 call effect_step
 ld ix,FX2
 call effect_step
 call render_audio
 ld hl,AGES
 ld b,4
age_loop:
 ld a,(hl)
 cp 63
 jr nc,age_next
 inc (hl)
age_next:
 inc hl
 djnz age_loop
 ret

change_mode:
 ld (MODE),a
 push af
 ld hl,NOTES
 ld de,NOTES+1
 ld bc,29
 xor a
 ld (hl),a
 ldir
 ld (MTIMER),a
 call silence
 ld a,255
 ld (REQUEST),a
 ld (NOISELAST),a
 pop af
 ld hl,0
 or a
 jr z,mode_ptr
 cp 2
 jr z,mode_ptr          ; Gameplay uses effects only: no music stream.
 ld hl,title_score
 cp 3
 jr nz,mode_ptr
 ld hl,end_score
mode_ptr:
 ld (MPTR),hl
 ; Snapshot initial frog state, so starting a round cannot make a splash.
 ld iy,07037h
 call frog_flags
 ld (PREV1),a
 ld a,(07035h)
 ld (PREV1+1),a
 ld iy,07044h
 call frog_flags
 ld (PREV2),a
 ld a,(07036h)
 ld (PREV2+1),a
 ret

music_step:
 ld hl,(MPTR)
 ld a,h
 or l
 ret z
 ld a,(MTIMER)
 or a
 jr z,music_record
 dec a
 ld (MTIMER),a
 ret nz
music_record:
 ld a,(hl)
 or a
 jr nz,music_valid
 ld a,(MODE)
 cp 3
 jr z,music_done
 ld hl,title_score
 ld a,(hl)
music_valid:
 ld (MTIMER),a
 inc hl
 ld iy,NOTES
 ld b,4
music_notes:
 ld a,(hl)
 inc hl
 cp 255
 jr z,music_next
 ld (iy+0),a
 ld (iy+4),0
music_next:
 inc iy
 djnz music_notes
 ld (MPTR),hl
 ret
music_done:
 ld hl,0
 ld (MPTR),hl
 xor a
 ld (NOTES),a
 ld (NOTES+1),a
 ld (NOTES+2),a
 ld (NOTES+3),a
 ret

; Frog structures are unchanged from the 2007 ROM.
; Flags: bit 0 hop/jump, bit 1 tongue, bit 2 water.
frog_flags:
 ld a,(iy+8)
 or (iy+9)
 and 1
 ld e,a
 ld a,(iy+7)
 and 1
 add a,a
 or e
 ld e,a
 ld a,(iy+6)
 and 1
 add a,a
 add a,a
 or e
 ret

poll_effects:
 ld iy,07037h
 ld ix,FX1
 ld hl,PREV1
 ld a,(07035h)
 ld c,a
 call poll_one
 ld iy,07044h
 ld ix,FX2
 ld hl,PREV2
 ld a,(07036h)
 ld c,a
poll_one:
 call frog_flags
 ld e,a
 xor (hl)
 and e
 ld b,a
 ld (hl),e
 inc hl
 xor a
 bit 0,b
 jr z,poll_tongue
 ld a,1
poll_tongue:
 bit 1,b
 jr z,poll_water
 ld a,2
poll_water:
 bit 2,b
 jr z,poll_score
 ld a,3
poll_score:
 ld e,a
 ld a,(hl)
 ld (hl),c
 cp c
 ld a,e
 jr nc,queue_effect
 ld a,4
queue_effect:
 or a
 ret z
 cp (ix+3)
 ret c
 ld (ix+3),a
 dec a
 add a,a
 ld e,a
 ld d,0
 ld hl,effect_table
 add hl,de
 ld a,(hl)
 ld (ix+0),a
 inc hl
 ld a,(hl)
 ld (ix+1),a
 ld (ix+2),0
 ret

; Five-byte records: duration, MIDI pitch, attenuation, noise rate, noise volume.
effect_step:
 ld a,(ix+3)
 or a
 ret z
 ld a,(ix+2)
 or a
 jr z,effect_record
 dec a
 ld (ix+2),a
 ret nz
effect_record:
 ld l,(ix+0)
 ld h,(ix+1)
 ld a,(hl)
 or a
 jr nz,effect_valid
 ld (ix+3),a
 ret
effect_valid:
 ld (ix+2),a
 inc hl
 ld a,(hl)
 ld (ix+4),a
 inc hl
 ld a,(hl)
 ld (ix+5),a
 inc hl
 ld a,(hl)
 ld (ix+6),a
 inc hl
 ld a,(hl)
 ld (ix+7),a
 inc hl
 ld (ix+0),l
 ld (ix+1),h
 ret

render_audio:
 ld a,(AGES)
 ld hl,env_lead
 call envelope
 ld a,(NOTES)
 ld e,080h
 call tone

 ld a,(AGES+1)
 ld hl,env_harmony
 call envelope
 ld a,(NOTES+1)
 ld ix,FX1
 call overlay_effect
 ld e,0a0h
 call tone

 ld a,(AGES+2)
 ld hl,env_bass
 call envelope
 ld a,(NOTES+2)
 ld ix,FX2
 call overlay_effect
 ld e,0c0h
 call tone

 ld a,(AGES+3)
 ld hl,env_drum
 call envelope
 ld a,(NOTES+3)
 or a
 jr nz,noise_music
 ld b,15
noise_music:
 ld e,6
 ld ix,FX1
 call overlay_noise
 ld ix,FX2
 call overlay_noise
 ld a,(NOISELAST)
 cp e
 jr z,noise_volume
 ld a,e
 ld (NOISELAST),a
 or 0e0h
 call psg_write
noise_volume:
 ld a,b
 or 0f0h
 jp psg_write

; Returns B = music attenuation; title and ending screens only.
envelope:
 ld c,a
 ld b,0
 add hl,bc
 ld b,(hl)
 ret

overlay_effect:
 ld c,a
 ld a,(ix+3)
 or a
 ld a,c
 ret z
 ; A noise-only splash does not use a tone voice.
 ld a,(ix+4)
 or a
 jr nz,overlay_tone
 ld a,c
 ret
overlay_tone:
 ld b,(ix+5)
 ret

overlay_noise:
 ld a,(ix+3)
 or a
 ret z
 ld a,(ix+7)
 cp b
 ret nc
 ld b,a
 ld e,(ix+6)
 ret

; A = MIDI note (0 = silence), B = attenuation, E = tone latch.
tone:
 or a
 jr nz,tone_pitch
 ld b,15
 jr tone_volume
tone_pitch:
 ld l,a
 ld h,0
 add hl,hl
 ld d,0
 push de
 ld de,periods
 add hl,de
 pop de
 ld c,(hl)
 inc hl
 ld d,(hl)
 ld a,c
 and 15
 or e
 call psg_write
 ld a,c
 rrca
 rrca
 rrca
 rrca
 and 15
 ld c,a
 ld a,d
 rlca
 rlca
 rlca
 rlca
 or c
 call psg_write
tone_volume:
 ld a,e
 or 010h
 or b
 jp psg_write

silence:
 ld a,09fh
 call psg_write
 ld a,0bfh
 call psg_write
 ld a,0dfh
 call psg_write
 ld a,0ffh
 jp psg_write

; Conservative write spacing for physical SN76489-family chips.
; Even consecutive CALLs are separated by more than 32 Z80 T-states.
psg_write:
 out (0ffh),a
 nop
 nop
 nop
 nop
 nop
 nop
 ret

effect_table:
 dw jump1,tongue1,splashnoise,grab1

 include "audio_data.inc"
audio_end:
