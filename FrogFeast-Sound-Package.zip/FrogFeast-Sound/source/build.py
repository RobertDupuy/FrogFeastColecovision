"""Build the sound-repaired ROM from the exact supplied 2007 cartridge image."""
from pathlib import Path
import hashlib, subprocess, sys
from convert_audio import main as convert

ROOT=Path(__file__).resolve().parent
EXPECTED='30ec012ff422cc2cf56f7613270696f19ec8590940835763b34f49d76fc01433'
base=(ROOT/'base.rom').read_bytes()
assert hashlib.sha256(base).hexdigest()==EXPECTED,'Wrong base ROM; refusing to patch.'
convert()
assembler=sys.argv[1] if len(sys.argv)>1 else 'pasmo'
subprocess.run([assembler,'--bin','audio.asm','audio.bin','audio.sym'],cwd=ROOT,check=True)
symbols={}
for line in (ROOT/'audio.sym').read_text().splitlines():
    parts=line.split()
    if len(parts)==3:symbols[parts[0]]=int(parts[2].rstrip('H'),16)
rom=bytearray(base)+bytearray([255])*(32768-len(base))
patches=[]
def patch(addr,expected,replacement,description):
    offset=addr-0x8000
    assert rom[offset:offset+len(expected)]==bytes.fromhex(expected.hex()),hex(addr)
    rom[offset:offset+len(replacement)]=replacement
    patches.append(f'{addr:04X}: {expected.hex(" ")} -> {replacement.hex(" ")} : {description}')
def redirect(addr,label,expected,op=0xc3):
    dest=symbols[label]
    patch(addr,bytes.fromhex(expected),bytes((op,dest&255,dest>>8)),label)
redirect(0x8109,'audio_init','21 33 00',0xcd)
redirect(0xa59d,'audio_tick','dd e5 fd')
redirect(0xa268,'title_request','2e 07 e5')
redirect(0x860c,'game_request','c3 22 a2')
redirect(0x8a94,'end_request','cd 62 a8',0xcd)
redirect(0xa862,'mute_request','3e 01 32')
patch(0xa83e,b'\xaf',b'\xc9','Disable old cached-volume restore')
for addr in (0xa222,0xa245,0xa28b,0xa2ae):
    patch(addr,b'\x2e',b'\xc9','Disable legacy effect; actual frog states drive replacement')
audio=(ROOT/'audio.bin').read_bytes()
assert 0x5500+len(audio)<=32768,'Sound code exceeds standard 32 KiB cartridge'
assert len(base)<=0x5500
rom[0x5500:0x5500+len(audio)]=audio
target=ROOT.parent/'FrogFeast-Sound.rom'
target.write_bytes(rom)
(ROOT/'patch-map.txt').write_text('\n'.join(patches)+f'\nD500-{0xd500+len(audio)-1:04X}: appended sound code and score\n')
print(f'{target.name}: {len(rom)} bytes; new audio {len(audio)} bytes')
print('SHA256',hashlib.sha256(rom).hexdigest())
