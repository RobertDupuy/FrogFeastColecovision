"""Convert the supplied Uzebox event streams to a compact SN76489 score."""
from pathlib import Path
import re, math, collections

ROOT = Path(__file__).resolve().parent

def events(name):
    src=(ROOT/'assets'/name).read_text()
    src=re.sub(r'/\*.*?\*/|//[^\n]*','',src,flags=re.S)
    data=bytes(int(n,16) for n in re.findall(r'0x([0-9a-fA-F]+)',src))
    p=t=status=0; notes=collections.defaultdict(dict); markers={}
    def byte():
        nonlocal p
        v=data[p];p+=1;return v
    def vlq():
        v=0
        while True:
            b=byte();v=(v<<7)|(b&127)
            if b<128:return v
    while p<len(data):
        t+=vlq()
        if data[p]>=128:status=byte()
        if status==255:
            kind=byte();length=vlq();payload=data[p:p+length];p+=length
            if kind==6:markers[payload.decode()]=t
            if kind==47:break
            continue
        kind=status>>4;ch=status&15
        n=byte();v=byte() if kind not in (12,13) else 0
        if kind in (8,9) and ch<4:
            if kind==8 or v==0:n=0
            elif ch==2:
                while n<45:n+=12
            elif ch<3:
                while n<45:n+=12
            notes[t][ch]=n
    return notes,t,markers

def score(name,label,loop=False):
    notes,end,markers=events(name)
    if loop and 'E' in markers:
        end=markers['E'];notes={t:n for t,n in notes.items() if t<end}
    times=sorted(notes)
    if times[0]!=0:times.insert(0,0)
    records=[]
    for i,t in enumerate(times):
        nxt=times[i+1] if i+1<len(times) else end
        delay=max(1,nxt-t)
        vals=[notes.get(t,{}).get(c,255) for c in range(4)]
        while delay>254:
            records.append([254]+vals);vals=[255]*4;delay-=254
        records.append([delay]+vals)
    lines=[label+':']
    for r in records:lines.append(' db '+','.join(str(x) for x in r))
    lines.append(' db 0,255,255,255,255')
    print(label,len(records),'records,',end,'frames,',round(end/60,2),'seconds')
    return '\n'.join(lines)

def effect(name):
    src=(ROOT/'assets/patches.inc').read_text()
    src=re.sub(r'/\*.*?\*/|//[^\n]*','',src,flags=re.S)
    body=re.search(r'const char '+name+r'\[\].*?\{(.*?)\}',src,re.S)[1]
    tokens=[s.strip() for s in body.split(',') if s.strip()]
    t=0;vol=0;speed=0;pitch=0;noise=6;cut=False;changes={};i=0
    while i<len(tokens):
        delay=int(tokens[i],0);cmd=tokens[i+1];i+=2;t+=delay
        if cmd=='PATCH_END':break
        value=int(tokens[i],0);i+=1
        changes.setdefault(t,[]).append((cmd,value))
    result=[]
    for frame in range(t+1):
        for cmd,value in changes.get(frame,[]):
            if cmd=='PC_ENV_VOL':vol=value
            if cmd=='PC_ENV_SPEED':speed=value
            if cmd=='PC_PITCH':pitch=value
            if cmd=='PC_NOTE_CUT':cut=True
            if cmd=='PC_NOISE_PARAMS':noise=6 if value>=3 else 5
        if cut:vol=0
        if name=='Grab1':n=max(45,pitch-12)
        else:n=pitch
        atten=15 if vol<=0 else min(14,max(5,round(-10*math.log10(min(1,vol/255)))+4))
        if name=='SplashNoise':r=[1,0,15,noise,atten]
        else:r=[1,n,atten,6,15]
        if result and result[-1][1:]==r[1:]:result[-1][0]+=1
        else:result.append(r)
        vol=min(255,max(0,vol+speed))
    return name.lower()+':\n'+'\n'.join(' db '+','.join(map(str,r)) for r in result)+'\n db 0,0,15,6,15'

def main():
    text=['; ColecoVision arrangement of supplied Lee Weber / Uzebox assets.',
          score('titlesong.inc','title_score',True),score('gameoversong.inc','end_score')]
    text += [effect(s) for s in ('Jump1','Tongue1','Tongue2','Grab1','SplashNoise')]
    text+=['periods:']
    values=[max(1,min(1023,round((3579545/32)/(440*2**((n-69)/12))))) for n in range(128)]
    for i in range(0,128,8):text.append(' dw '+','.join(map(str,values[i:i+8])))
    envelopes={
        'env_lead':[5]*2+[6]*6+[7]*12+[8]*16+[9]*16+[10]*12,
        'env_harmony':[8]*2+[7]*3+[8]*3+[9]*3+[11]*3+[13]*3+[15]*47,
        'env_bass':[6]*2+[7]*2+[8]*2+[10]*2+[12]*2+[15]*54,
        'env_drum':[11,12,13,15]+[15]*60,
    }
    for label,env in envelopes.items():
        assert len(env)==64
        text.append(label+':')
        for i in range(0,64,16):text.append(' db '+','.join(map(str,env[i:i+16])))
    (ROOT/'audio_data.inc').write_text('\n\n'.join(text)+'\n')

if __name__=='__main__':main()
