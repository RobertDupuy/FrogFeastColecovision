#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <z80ex/z80ex.h>

static unsigned char mem[65536];
static long long cycles,last_write=-100000,spacing=1000000;
static unsigned writes,badwrites,maxcycles;
static int latch,period[4],volume[4]={15,15,15,15};
static FILE *trace;
static int frame;
static unsigned char rd(Z80EX_CONTEXT*c,uint16_t a,int m1,void*u){return mem[a];}
static void wr(Z80EX_CONTEXT*c,uint16_t a,unsigned char v,void*u){
 if(!((a>=0x71a1&&a<0x71e1)||(a>=0x7300&&a<=0x7350)))badwrites++;
 mem[a]=v;
}
static unsigned char in(Z80EX_CONTEXT*c,uint16_t p,void*u){return 255;}
static unsigned char ir(Z80EX_CONTEXT*c,void*u){return 255;}
static void out(Z80EX_CONTEXT*c,uint16_t p,unsigned char v,void*u){
 assert((p&255)==255);
 long long time=cycles+z80ex_op_tstate(c);
 if(time-last_write<spacing)spacing=time-last_write;
 last_write=time;writes++;
 if(v&128){latch=(v>>4)&7; if(latch&1)volume[latch>>1]=v&15;
   else if(latch<6)period[latch>>1]=(period[latch>>1]&0x3f0)|(v&15);
 }else if(!(latch&1)&&latch<6)period[latch>>1]=(period[latch>>1]&15)|((v&63)<<4);
 if(trace)fprintf(trace,"%d,%lld,%02x\n",frame,time,v);
}
static unsigned run(Z80EX_CONTEXT*c,unsigned addr){
 z80ex_set_reg(c,regPC,addr);z80ex_set_reg(c,regSP,0x734e);
 mem[0x734e]=0;mem[0x734f]=0x7f;
 unsigned used=0;
 while(z80ex_get_reg(c,regPC)!=0x7f00){int n=z80ex_step(c);cycles+=n;used+=n;assert(used<30000);}
 assert(z80ex_get_reg(c,regSP)==0x7350);
 if(used>maxcycles)maxcycles=used;
 return used;
}
int main(int argc,char**argv){
 assert(argc==4);
 FILE*f=fopen(argv[1],"rb");assert(f);assert(fread(mem+0x8000,1,32768,f)==32768);fclose(f);
 unsigned init=strtol(argv[2],0,16),tick=strtol(argv[3],0,16);
 Z80EX_CONTEXT*c=z80ex_create(rd,0,wr,0,in,0,out,0,ir,0);
 run(c,init);assert(z80ex_get_reg(c,regHL)==0x33);
 for(int i=0;i<4;i++)assert(volume[i]==15);
 maxcycles=0;mem[0x71a2]=1;
 unsigned long total=0;unsigned audible=0;
 for(frame=0;frame<5400;frame++){
   total+=run(c,tick);cycles+=60000;
   if(volume[0]<15)audible++;
   assert(period[0]>0&&period[0]<=1023);
 }
 assert(audible>5300);
 printf("Music loop: 5400 frames; mean %lu, max %u CPU cycles\n",total/5400,maxcycles);
 mem[0x71a2]=2;run(c,tick);
 for(int i=0;i<600;i++){
   for(int v=0;v<4;v++)assert(volume[v]==15);
   frame++;run(c,tick);cycles+=60000;
 }
 printf("Gameplay without effects: all four channels silent for 600 frames: PASS\n");
 for(int event=1;event<=4;event++){
   for(int p=0;p<2;p++){
     unsigned frog=p?0x7044:0x7037;
     if(event==1)mem[frog+9]=1;
     if(event==2)mem[frog+7]=1;
     if(event==3)mem[frog+6]=1;
     if(event==4)mem[0x7035+p]+=2;
   }
   run(c,tick);
   assert(mem[0x71b4]==event&&mem[0x71bc]==event);
   assert(volume[0]==15);
   if(event==3)assert(volume[3]<15);
   else assert(volume[1]<15&&volume[2]<15);
   for(int i=0;i<70;i++){frame++;run(c,tick);cycles+=60000;}
   assert(mem[0x71b4]==0&&mem[0x71bc]==0);
   for(int v=0;v<4;v++)assert(volume[v]==15);
 }
 printf("Simultaneous two-player jump, tongue, splash, catch; silence after effects: PASS\n");
 mem[0x71a2]=3;
 for(int i=0;i<600;i++){frame++;run(c,tick);cycles+=60000;}
 for(int i=0;i<4;i++)assert(volume[i]==15);
 printf("Ending track terminates and silences all four channels: PASS\n");
 mem[0x71a2]=1;run(c,tick);assert(volume[0]<15);
 mem[0x71a2]=0;run(c,tick);for(int i=0;i<4;i++)assert(volume[i]==15);
 assert(!badwrites);assert(spacing>=32);
 printf("Memory / stack boundaries: PASS; minimum PSG spacing %lld T-states\n",spacing);
 printf("Worst observed audio tick %u cycles = %.2f%% NTSC frame\n",maxcycles,maxcycles*100.0/59736);
 z80ex_destroy(c);return 0;
}
